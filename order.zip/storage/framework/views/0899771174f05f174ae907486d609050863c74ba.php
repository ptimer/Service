<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Управление сайтом</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <h4>Администраторы</h4>
                            <ul class="list-group list-group-flush">
                                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item"><?php echo e($admin->email); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-md-4">
                            <div class="container">
                                
                                <div class="row">
                                    <div class="col-md-8"><h4>Операторы</h4></div>
                                    <div class="col-md-4">
                                        <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-plus"></i></button>
                                    </div>
                                </div>
                            </div>
                            

                            
                            <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content p-5">
                                         
                                        <form method="POST" action="<?php echo e(route('operator.register')); ?>">
                                            <?php echo csrf_field(); ?>

                                            <div class="form-group row">
                                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Имя')); ?></label>

                                                <div class="col-md-6">
                                                    <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail адрес')); ?></label>

                                                <div class="col-md-6">
                                                    <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Пароль')); ?></label>

                                                <div class="col-md-6">
                                                    <input id="password" type="text" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Подтвердить пароль')); ?></label>

                                                <div class="col-md-6">
                                                    <input id="password-confirm" type="text" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-0">
                                                <div class="col-md-6 offset-md-4">
                                                    <button type="submit" class="btn btn-primary">
                                                        <?php echo e(__('Зарегистрировать оператора')); ?>

                                                    </button>
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                 </div>
                            </div>
                            <ul class="list-group list-group-flush">
                                <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li class="list-group-item">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-8">
                                                    <h6>Имя: </h6> <?php echo e($operator->name); ?>

                                                    <h6>Email: </h6> <?php echo e($operator->email); ?>

                                                </div>
                                    
                                                <div class="col-md-4">

                                                    <button class="btn btn-sm btn-danger" type="button" data-toggle="modal" data-toggle="modal" data-target=".delete-modal<?php echo e($operator->id); ?>">
                                                            <i class="fa fa-trash"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-primary" type="button" data-toggle="modal" data-toggle="modal" data-target=".update-modal<?php echo e($operator->id); ?>">
                                                            <i class="fa fa-edit"></i>
                                                    </button>
                                                </div>
                                    </li>
                                    
                                   <div class="modal fade delete-modal<?php echo e($operator->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content p-5">
                                          <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Удаление <?php echo e($operator->email); ?></h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                              <span aria-hidden="true">&times;</span>
                                            </button>
                                          </div>
                                          <div class="modal-body">
                                            <p><span style="font-size: 15px; font-weight: bold;">Вы действительно хотите удалить оператора ? </span></p>
                                            <p> ID: <?php echo e($operator->id); ?> </p>
                                            <p> EMAIL: <?php echo e($operator->email); ?> </p>
                                            <p> Имя: <?php echo e($operator->name); ?> </p>
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Отменить</button>
                                            <form method="POST" action="<?php echo e(route('admin.destroyOperator', ['id' => $operator->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input type="hidden" name="id" value="<?php echo e($operator->id); ?>">
                                                <button type="submit" class="btn btn-primary">Подтвердить удаление</button>
                                            </form>
                                          </div>
                                        </div>
                                    </div>
                                    </div>

                                    

                                    <div class="modal fade update-modal<?php echo e($operator->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content p-5">
                                          <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Изменение <?php echo e($operator->email); ?></h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                              <span aria-hidden="true">&times;</span>
                                            </button>
                                          </div>
                                          <div class="modal-body">

                                            <form method="POST" action="<?php echo e(route('admin.updateOperator', ['id' => $operator->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <input type="hidden" name="id" value="<?php echo e($operator->id); ?>">
                                                <div class="form-group row">
                                                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Имя')); ?></label>

                                                    <div class="col-md-6">
                                                        <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e($operator->name); ?>" required autocomplete="name" autofocus>

                                                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail адрес')); ?></label>

                                                    <div class="col-md-6">
                                                        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($operator->email); ?>" required autocomplete="email">

                                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Пароль')); ?></label>

                                                    <div class="col-md-6">
                                                        <input id="password" type="text" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">
                                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Подтвердить пароль')); ?></label>

                                                    <div class="col-md-6">
                                                        <input id="password-confirm" type="text" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Отменить</button>
                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Сохранить изменения')); ?></button>
                                                </div>
                                            </form>
                                          </div>
                                        </div>
                                    </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-md-4">
                            <h4>Клиенты</h4>
                            <ul class="list-group list-group-flush">
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item"><?php echo e($client->email); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ilya\Desktop\order\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>